<?= $this->extend('master') ?>

<?= $this->section('content') ?>

<div class="row mt-5">
    <div class="col-xl-4 col-md-6 col-sm-8 col-10 mx-auto">
        <div class="card">
            <form action="<?= base_url() ?>/tambah-pelayanan" method="post">
                <div class="card-header">
                    <h2 class="my-3 text-center">Tambah Pelayanan</h2>
                </div>

                <div class="card-body py-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Kode Pelayanan</label>
                        <input type="text" class="form-control" maxlength="2" name="kode_pelayanan" placeholder="Contoh: CS" value="<?= old('kode_pelayanan') ?>">
                    </div>

                    <div class="">
                        <label for="" class="form-label">Nama Pelayanan</label>
                        <input type="text" class="form-control" name="nama_pelayanan"placeholder="Contoh: Customer Services" value="<?= old('nama_pelayanan') ?>">
                    </div>
                </div>

                <div class="card-footer p-3">
                    <button type="submit" class="btn btn-warning">Tambah</button>
                </div>
            </form>
        </div>

    </div>
</div>
<?= $this->endSection() ?>